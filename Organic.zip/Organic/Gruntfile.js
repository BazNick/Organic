module.exports = function (grunt) {
  grunt.loadNpmTasks('grunt-contrib-sass');
  grunt.loadNpmTasks('grunt-contrib-watch');
  grunt.loadNpmTasks('grunt-autoprefixer');
  grunt.initConfig ({
    pkg: grunt.file.readJSON('package.json'),
    sass: {
      styles: { 
        files: {
          "styles.css": "sass/styles.scss"
        }
      }
    },
      autoprefixer: {
          options: {
              browsers: ["last 2 versions", "ie 8", "ie 9"]
          },
          styles: {
              src: "*.css"
          }       
      },
      watch: {
      styles: {
        files: ["sass/*.scss", "*.html"],
        tasks: ["sass", "autoprefixer"]
    }
  }
  });
};
